(function () {

  if (window.__itafInstalled) return;
  window.__itafInstalled = true;

  // Global state
  window.__itafCaptureEnabled = false;
  window.__lastCapturedElement = null;
  window.__itafElementUpdated = false;

  let lastHighlighted = null;
  let listenersAttached = false;

  /* =====================
     HOVER HIGHLIGHT
     ===================== */
  window.__itafMouseOver = function (e) {
    if (!window.__itafCaptureEnabled) return;

    if (lastHighlighted) {
      lastHighlighted.style.outline = "";
    }
    lastHighlighted = e.target;
    e.target.style.outline = "2px solid red";
  };

  window.__itafMouseOut = function (e) {
    if (!window.__itafCaptureEnabled) return;

    if (e.target === lastHighlighted) {
      e.target.style.outline = "";
      lastHighlighted = null;
    }
  };

  /* =====================
     CLICK CAPTURE
     ===================== */
  window.__itafClickHandler = function (e) {
    if (!window.__itafCaptureEnabled) return;

    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();

    const el = e.target;

    function getXPath(el) {
      if (el.id) return `//*[@id="${el.id}"]`;
      if (el === document.body) return "/html/body";

      let ix = 0;
      const siblings = el.parentNode.childNodes;
      for (let i = 0; i < siblings.length; i++) {
        const sib = siblings[i];
        if (sib === el)
          return getXPath(el.parentNode) + "/" +
                 el.tagName.toLowerCase() + "[" + (ix + 1) + "]";
        if (sib.nodeType === 1 && sib.tagName === el.tagName) ix++;
      }
    }

    const attrs = {};
    for (let a of el.attributes) {
      attrs[a.name] = a.value;
    }

    window.__lastCapturedElement = {
      tag: el.tagName.toLowerCase(),
      text: el.innerText?.trim() || "",
      attributes: attrs,
      xpath: getXPath(el)
    };

    window.__itafElementUpdated = true;
  };

  /* =====================
     ATTACH / DETACH HELPERS
     ===================== */
  function attachListeners() {
    if (listenersAttached) return;

    document.addEventListener("mouseover", window.__itafMouseOver, true);
    document.addEventListener("mouseout", window.__itafMouseOut, true);
    document.addEventListener("click", window.__itafClickHandler, true);

    listenersAttached = true;
  }

  function detachListeners() {
    if (!listenersAttached) return;

    document.removeEventListener("mouseover", window.__itafMouseOver, true);
    document.removeEventListener("mouseout", window.__itafMouseOut, true);
    document.removeEventListener("click", window.__itafClickHandler, true);

    listenersAttached = false;
  }

  /* =====================
     ENABLE / DISABLE API
     ===================== */
  window.__itafEnableCapture = function () {
    window.__itafCaptureEnabled = true;
    attachListeners();
  };

  window.__itafDisableCapture = function () {
    window.__itafCaptureEnabled = false;

    detachListeners();

    if (lastHighlighted) {
      lastHighlighted.style.outline = "";
      lastHighlighted = null;
    }
  };

})();

