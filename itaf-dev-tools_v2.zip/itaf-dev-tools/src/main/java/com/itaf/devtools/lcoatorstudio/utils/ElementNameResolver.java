package com.itaf.devtools.lcoatorstudio.utils;

import java.util.Map;

public class ElementNameResolver {

    public static String resolve(
            String tag,
            Map<String, String> attrs,
            int index) {

        if (attrs.containsKey("data-testid"))
            return sanitize(attrs.get("data-testid"));

        if (attrs.containsKey("aria-label"))
            return sanitize(attrs.get("aria-label"));

        if (attrs.containsKey("id"))
            return sanitize(attrs.get("id"));

        if (attrs.containsKey("name"))
            return sanitize(attrs.get("name"));

        return tag + "_" + index;
    }

    private static String sanitize(String s) {
        return s.replaceAll("[^a-zA-Z0-9_-]", "");
    }
}
