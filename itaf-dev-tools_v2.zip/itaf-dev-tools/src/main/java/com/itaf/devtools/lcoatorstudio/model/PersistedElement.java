package com.itaf.devtools.lcoatorstudio.model;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

public class PersistedElement {

    public String elementName;
    public String tag;
    public String text;
    public Map<String, String> attributes;

    public LocatorCandidate bestLocator;
    public List<LocatorCandidate> allLocators;

    public String screenshotPath;
    public LocalDateTime capturedAt;

    public PersistedElement() {
    }
}
