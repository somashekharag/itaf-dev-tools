package com.itaf.devtools.utils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 * ITAFClickUtil - click helpers
 */
public class ITAFClickUtil {

    protected final WebDriver driver;
    protected final ITAFWaitUtil wait;

    public ITAFClickUtil(WebDriver driver) {
        this.driver = driver;
        this.wait = new ITAFWaitUtil(driver);
    }

    /**
     * Click using a locator with waiting for element to be clickable.
     */
    public void click(By locator) {
        wait.clickable(locator).click();
    }

    /**
     * Click using a PageFactory WebElement.
     */
    public void click(WebElement element) {
        wait.clickable(element).click();
    }
}
