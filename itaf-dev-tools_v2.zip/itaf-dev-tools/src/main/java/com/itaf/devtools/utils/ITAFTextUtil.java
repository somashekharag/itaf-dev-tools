package com.itaf.devtools.utils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 * ITAFTextUtil - typing helpers
 */
public class ITAFTextUtil {

    protected final WebDriver driver;
    protected final ITAFWaitUtil wait;

    public ITAFTextUtil(WebDriver driver) {
        this.driver = driver;
        this.wait = new ITAFWaitUtil(driver);
    }

    /**
     * Type into element found by locator: waits for visibility, clears, types.
     */
    public void type(By locator, String value) {
        WebElement el = wait.visible(locator);
        el.clear();
        el.sendKeys(value);
    }

    /**
     * Type into PageFactory WebElement.
     */
    public void type(WebElement element, String value) {
        WebElement el = wait.visible(element);
        el.clear();
        el.sendKeys(value);
    }
}
