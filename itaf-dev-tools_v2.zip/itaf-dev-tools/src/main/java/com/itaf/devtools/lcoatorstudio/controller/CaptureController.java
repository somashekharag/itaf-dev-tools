package com.itaf.devtools.lcoatorstudio.controller;

import com.itaf.devtools.lcoatorstudio.selenium.DriverStore;
import com.itaf.devtools.lcoatorstudio.utils.DevToolsContext;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Map;

@RestController
@RequestMapping("/api/capture")
public class CaptureController {

//    @PostMapping("/enable")
//    public Map<String, String> enableCapture() {
//
//        WebDriver driver = DriverStore.get();
//        if (driver == null) {
//            return Map.of("status", "NO_BROWSER");
//        }
//
//        ((JavascriptExecutor) driver).executeScript(loadScript());
//
//        return Map.of(
//                "status", "CAPTURE_ENABLED",
//                "message", "Locator capture enabled"
//        );
//    }
//
//    private String loadScript() {
//        try (InputStream is =
//                     getClass().getClassLoader().getResourceAsStream("locator-capture.js")) {
//
//            return new String(is.readAllBytes(), StandardCharsets.UTF_8);
//        } catch (Exception e) {
//            throw new RuntimeException("Failed to load locator-capture.js", e);
//        }
//    }

    @PostMapping("/enable")
    public Map<String, String> enableCapture(
            @RequestParam(required = false) String page) {

        if (page == null || page.isBlank()) {
            return Map.of(
                    "status", "PAGE_NOT_SELECTED",
                    "message", "Select a page before enabling capture"
            );
        }

        WebDriver driver = DriverStore.get();
        if (driver == null) {
            return Map.of("status", "NO_BROWSER");
        }

        JavascriptExecutor js = (JavascriptExecutor) driver;

        js.executeScript(loadScript());
        js.executeScript("window.__itafEnableCapture && window.__itafEnableCapture();");

        // Store page in context (ThreadLocal / ScenarioContext)
        System.out.println("setting the current page as "+ page);
        DevToolsContext.setCurrentPage(driver, page);

        return Map.of(
                "status", "CAPTURE_ENABLED",
                "page", page
        );
    }

    @PostMapping("/disable")
    public Map<String, String> disableCapture() {

        WebDriver driver = DriverStore.get();
        if (driver == null) {
            return Map.of("status", "NO_BROWSER");
        }

        ((JavascriptExecutor) driver).executeScript(
                "window.__itafDisableCapture && window.__itafDisableCapture();"
        );

        return Map.of(
                "status", "CAPTURE_DISABLED",
                "message", "Locator capture disabled"
        );
    }

        private String loadScript() {
        try (InputStream is =
                     getClass().getClassLoader().getResourceAsStream("locator-capture.js")) {

            return new String(is.readAllBytes(), StandardCharsets.UTF_8);
        } catch (Exception e) {
            throw new RuntimeException("Failed to load locator-capture.js", e);
        }
    }
}
