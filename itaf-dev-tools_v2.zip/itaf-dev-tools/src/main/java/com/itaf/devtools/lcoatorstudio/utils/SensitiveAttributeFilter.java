package com.itaf.devtools.lcoatorstudio.utils;

import java.util.*;
import java.util.regex.Pattern;

public class SensitiveAttributeFilter {

    private static final Set<String> BLOCKED_NAMES = Set.of(
        "password", "passwd", "pwd", "value",
        "token", "secret", "apikey", "api-key",
        "authorization", "auth",
        "session", "sessionid", "jsessionid",
        "csrf", "xsrf", "_csrf",
        "cookie"
    );

    private static final List<Pattern> BLOCKED_PATTERNS = List.of(
        Pattern.compile(".*token.*", Pattern.CASE_INSENSITIVE),
        Pattern.compile(".*secret.*", Pattern.CASE_INSENSITIVE),
        Pattern.compile(".*password.*", Pattern.CASE_INSENSITIVE),
        Pattern.compile(".*session.*", Pattern.CASE_INSENSITIVE),
        Pattern.compile(".*auth.*", Pattern.CASE_INSENSITIVE),
        Pattern.compile(".*key.*", Pattern.CASE_INSENSITIVE)
    );

    public static boolean isSensitive(String attrName) {
        String key = attrName.toLowerCase();

        if (BLOCKED_NAMES.contains(key)) {
            return true;
        }

        return BLOCKED_PATTERNS.stream()
                .anyMatch(p -> p.matcher(key).matches());
    }
}
