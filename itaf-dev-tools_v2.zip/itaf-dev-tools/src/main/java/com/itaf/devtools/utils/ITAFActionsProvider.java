package com.itaf.devtools.utils;

import org.openqa.selenium.WebDriver;

/**
 * Provider interface to supply custom ITAF utilities.
 */
public interface ITAFActionsProvider {

    ITAFWaitUtil wait(WebDriver driver);
    ITAFElementUtil element(WebDriver driver);
    ITAFClickUtil click(WebDriver driver);
    ITAFTextUtil text(WebDriver driver);
    ITAFBrowserUtil browser(WebDriver driver);
    ITAFAlertUtil alert(WebDriver driver);
    ITAFJavascriptUtil js(WebDriver driver);
    ITAFScreenshotUtil screenshot(WebDriver driver);
}
