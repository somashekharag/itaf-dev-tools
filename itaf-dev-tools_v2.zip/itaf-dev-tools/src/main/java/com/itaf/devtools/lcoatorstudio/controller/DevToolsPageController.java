package com.itaf.devtools.lcoatorstudio.controller;

import com.itaf.devtools.config.DevToolsProperties;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
public class DevToolsPageController {

    private final DevToolsProperties properties;

    public DevToolsPageController(DevToolsProperties properties) {
        this.properties = properties;
    }

    @GetMapping("/api/devtools/pages")
    public Map<String, Object> getPages() {
        List<String> pages = properties.getPages();
        return Map.of(
            "pages", pages == null ? List.of() : pages
        );
    }
}
