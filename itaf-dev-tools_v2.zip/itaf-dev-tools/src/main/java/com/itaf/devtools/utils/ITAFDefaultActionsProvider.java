package com.itaf.devtools.utils;

import org.openqa.selenium.WebDriver;

/**
 * Default provider - returns ITAF core implementations.
 */
public class ITAFDefaultActionsProvider implements ITAFActionsProvider {

    @Override
    public ITAFWaitUtil wait(WebDriver d) { return new ITAFWaitUtil(d); }

    @Override
    public ITAFElementUtil element(WebDriver d) { return new ITAFElementUtil(d); }

    @Override
    public ITAFClickUtil click(WebDriver d) { return new ITAFClickUtil(d); }

    @Override
    public ITAFTextUtil text(WebDriver d) { return new ITAFTextUtil(d); }

    @Override
    public ITAFBrowserUtil browser(WebDriver d) { return new ITAFBrowserUtil(d); }

    @Override
    public ITAFAlertUtil alert(WebDriver d) { return new ITAFAlertUtil(d); }

    @Override
    public ITAFJavascriptUtil js(WebDriver d) { return new ITAFJavascriptUtil(d); }

    @Override
    public ITAFScreenshotUtil screenshot(WebDriver d) { return new ITAFScreenshotUtil(d); }
}
