
package com.itaf.devtools.lcoatorstudio.selenium;

import org.openqa.selenium.WebDriver;

public class DriverStore {
    private static WebDriver driver;
    public static void set(WebDriver d) { driver = d; }
    public static WebDriver get() { return driver; }
}
