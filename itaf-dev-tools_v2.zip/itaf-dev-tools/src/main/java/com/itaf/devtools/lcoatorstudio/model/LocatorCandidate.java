
package com.itaf.devtools.lcoatorstudio.model;

public class LocatorCandidate {

    public String type;
    public String value;
    public int score;

    // ✅ REQUIRED by Jackson
    public LocatorCandidate() {
    }

    public LocatorCandidate(String type, String value) {
        this.type = type;
        this.value = value;
    }
}
