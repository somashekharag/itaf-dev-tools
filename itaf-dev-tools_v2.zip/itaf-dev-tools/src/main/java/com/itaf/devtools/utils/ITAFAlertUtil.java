package com.itaf.devtools.utils;

import org.openqa.selenium.Alert;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;

/**
 * ITAFAlertUtil - alert helpers using ITAFWaitUtil.
 */
public class ITAFAlertUtil {

    protected final WebDriver driver;
    protected final ITAFWaitUtil wait;

    public ITAFAlertUtil(WebDriver driver) {
        this.driver = driver;
        this.wait = new ITAFWaitUtil(driver);
    }

    public boolean isPresent() {
        try {
            wait.until(d -> d.switchTo().alert());
            return true;
        } catch (TimeoutException e) {
            return false;
        }
    }

    public void acceptIfPresent() {
        if (isPresent()) {
            Alert a = driver.switchTo().alert();
            a.accept();
        }
    }
}
