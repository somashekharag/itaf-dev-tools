package com.itaf.devtools.lcoatorstudio.scanner;

import com.itaf.devtools.lcoatorstudio.config.LocatorScoringProperties;
import com.itaf.devtools.lcoatorstudio.model.LocatorCandidate;
import org.springframework.stereotype.Service;

@Service
public class LocatorScoringService {

    private final LocatorScoringProperties props;

    public LocatorScoringService(LocatorScoringProperties props) {
        this.props = props;
    }

    public int score(LocatorCandidate candidate) {
        int score = 0;

        switch (candidate.type) {
            case "css":
                if (candidate.value.contains("data-")) {
                    score += props.getDataAttribute();
                } else {
                    score += props.getCss();
                }
                break;

            case "id":
                score += props.getId();
                break;

            case "xpath":
                score += props.getXpath();
                break;
        }

        // Stability rules
        if (!candidate.value.matches(".*\\d+.*")) {
            score += props.getStableBonus();
        } else {
            score += props.getNumericPenalty();
        }

        return score;
    }
}
