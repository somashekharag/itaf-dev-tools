
package com.itaf.devtools.lcoatorstudio.model;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

public class ScannedElement {
    public String tag;
    public String text;
    public Map<String, String> attributes;
    public LocatorCandidate bestLocator;
    public List<LocatorCandidate> allLocators;
    public LocalDateTime capturedAt;

    public ScannedElement() {
    }
}
