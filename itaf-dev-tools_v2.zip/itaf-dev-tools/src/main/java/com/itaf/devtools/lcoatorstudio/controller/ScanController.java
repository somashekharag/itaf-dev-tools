
package com.itaf.devtools.lcoatorstudio.controller;

import com.itaf.devtools.lcoatorstudio.model.PersistedElement;
import com.itaf.devtools.lcoatorstudio.model.ScannedElement;
import com.itaf.devtools.lcoatorstudio.scanner.LocatorPersistenceService;
import com.itaf.devtools.lcoatorstudio.scanner.LocatorScannerUtil;
import com.itaf.devtools.lcoatorstudio.scanner.LocatorScoringService;
import com.itaf.devtools.lcoatorstudio.selenium.DriverStore;
import com.itaf.devtools.lcoatorstudio.selenium.ElementScreenshotUtil;
import com.itaf.devtools.lcoatorstudio.utils.DevToolsContext;
import com.itaf.devtools.lcoatorstudio.utils.ElementNameResolver;
import com.itaf.devtools.lcoatorstudio.utils.PageNameResolver;
import org.openqa.selenium.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/scan")
public class ScanController {

    private final LocatorScoringService scoringService;
    private final LocatorPersistenceService persistenceService;

    public ScanController(
            LocatorScoringService scoringService,
            LocatorPersistenceService persistenceService) {
        this.scoringService = scoringService;
        this.persistenceService = persistenceService;
    }

    @GetMapping
    public Object scan() {

        WebDriver driver = DriverStore.get();


//        WebDriver driver = DriverStore.get();
//        if (driver == null) {
//            return Map.of("status", "NO_BROWSER");
//        }
//
//        Boolean updated = (Boolean) ((JavascriptExecutor) driver)
//                .executeScript("return window.__itafElementUpdated === true;");
//
//        // ✅ Scan only when a NEW element is clicked
//        if (!Boolean.TRUE.equals(updated)) {
//            return Map.of(
//                    "status", "NO_CHANGE",
//                    "message", "Waiting for element click"
//            );
//        }
//
//        Object rawObj = ((JavascriptExecutor) driver)
//                .executeScript("return window.__lastCapturedElement;");
//
//        if (rawObj == null) {
//            return Map.of("status", "NO_ELEMENT");
//        }
//
//        // Reset flag AFTER reading
//        ((JavascriptExecutor) driver)
//                .executeScript("window.__itafElementUpdated = false;");
//
//        Map<String, Object> raw = (Map<String, Object>) rawObj;
//
//        WebElement element;
//        try {
//            element = driver.findElement(
//                    By.xpath((String) raw.get("xpath")));
//        } catch (NoSuchElementException e) {
//            return Map.of(
//                    "status", "STALE_ELEMENT",
//                    "message", "Element no longer present in DOM"
//            );
//        }
//
//        LocatorScannerUtil scanner =
//                new LocatorScannerUtil(driver, scoringService);
//
//
//        ScannedElement scanned = scanner.scan(
//                element,
//                (Map<String, String>) raw.get("attributes"),
//                (String) raw.get("text")
//        );


        if (driver == null) {
            return Map.of(
                    "status", "NO_BROWSER",
                    "message", "Browser not started"
            );
        }

        JavascriptExecutor js = (JavascriptExecutor) driver;

        // 🔔 Scan ONLY when a new click occurred
        Boolean updated = (Boolean) js.executeScript(
                "return window.__itafElementUpdated === true;"
        );

        if (!Boolean.TRUE.equals(updated)) {
            return Map.of(
                    "status", "NO_CHANGE",
                    "message", "Waiting for element click"
            );
        }

        Object rawObj = js.executeScript(
                "return window.__lastCapturedElement || null;"
        );

        if (rawObj == null) {
            // Reset event flag to avoid deadlock
            js.executeScript("window.__itafElementUpdated = false;");
            return Map.of(
                    "status", "NO_ELEMENT",
                    "message", "No element captured"
            );
        }

        @SuppressWarnings("unchecked")
        Map<String, Object> raw = (Map<String, Object>) rawObj;

        String xpath = (String) raw.get("xpath");
        if (xpath == null || xpath.isBlank()) {
            js.executeScript("window.__itafElementUpdated = false;");
            return Map.of(
                    "status", "INVALID_DATA",
                    "message", "Missing xpath in captured data"
            );
        }

        WebElement element;
        try {
            element = driver.findElement(By.xpath(xpath));
        } catch (NoSuchElementException e) {
            js.executeScript("window.__itafElementUpdated = false;");
            return Map.of(
                    "status", "STALE_ELEMENT",
                    "message", "Element no longer present in DOM"
            );
        }

        @SuppressWarnings("unchecked")
        Map<String, String> attributes =
                (Map<String, String>) raw.getOrDefault("attributes", Map.of());

        String text = (String) raw.getOrDefault("text", "");

        // 🔎 Run scanner ONCE for this click
        LocatorScannerUtil scanner =
                new LocatorScannerUtil(driver, scoringService);

        ScannedElement scanned = scanner.scan(element, attributes, text);

        // 🔄 IMPORTANT: reset ONLY the event flag (keep capture enabled)
        js.executeScript("window.__itafElementUpdated = false;");

        // 1️⃣ User selection wins
//        String pageName;
//        if (DevToolsContext.hasPageSelected()) {
//            pageName = DevToolsContext.getCurrentPage();
//        }

        String pageName = DevToolsContext.getCurrentPage(driver);
        if (pageName == null) {
            throw new IllegalStateException("Page not selected");
        }

        System.out.println("Current page name: "+pageName);
//        else {
//            pageName = PageNameResolver.resolve(
//                    driver.getCurrentUrl(),
//                    driver.getTitle());
//        }
        String elementName = ElementNameResolver.resolve(
                scanned.tag,
                scanned.attributes,
                scanned.allLocators.size());

        String screenshotPath =
                ElementScreenshotUtil.capture(
                        element,
                        pageName,
                        elementName);

        PersistedElement persisted = new PersistedElement();
        persisted.elementName = elementName;
        persisted.tag = scanned.tag;
        persisted.text = scanned.text;
        persisted.attributes = scanned.attributes;
        persisted.bestLocator = scanned.bestLocator;
        persisted.allLocators = scanned.allLocators;
        persisted.screenshotPath = screenshotPath;
        persisted.capturedAt = scanned.capturedAt;

        persistenceService.persist(pageName, persisted);

        return scanned;
    }
}