package com.itaf.devtools.lcoatorstudio.utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class DevToolsContext {

    private static final Map<String, String> PAGE_BY_SESSION =
            new ConcurrentHashMap<>();

    private DevToolsContext() {}

    private static String sessionId(WebDriver driver) {
        if (driver instanceof RemoteWebDriver) {
            return ((RemoteWebDriver) driver).getSessionId().toString();
        }
        // fallback for local drivers
        return String.valueOf(System.identityHashCode(driver));
    }

    /* ============================
       PAGE NAME
       ============================ */

    public static void setCurrentPage(WebDriver driver, String pageName) {
        PAGE_BY_SESSION.put(sessionId(driver), pageName);
    }

    public static String getCurrentPage(WebDriver driver) {
        return PAGE_BY_SESSION.get(sessionId(driver));
    }

    public static boolean hasPageSelected(WebDriver driver) {
        String page = getCurrentPage(driver);
        return page != null && !page.isBlank();
    }

    /* ============================
       CLEAR
       ============================ */

    public static void clear(WebDriver driver) {
        PAGE_BY_SESSION.remove(sessionId(driver));
    }
}
