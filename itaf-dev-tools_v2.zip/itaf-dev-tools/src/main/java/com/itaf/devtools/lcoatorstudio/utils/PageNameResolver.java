package com.itaf.devtools.lcoatorstudio.utils;

import java.net.URI;

public class PageNameResolver {

    public static String resolve(String url, String title) {

        try {
            URI uri = URI.create(url);
            String path = uri.getPath();

            if (path != null && !path.equals("/") && !path.isBlank()) {
                String[] parts = path.split("/");
                String last = parts[parts.length - 1];
                return capitalize(last) + "Page";
            }
        } catch (Exception ignored) {}

        if (title != null && !title.isBlank()) {
            return title.replaceAll("[^a-zA-Z0-9]", "") + "Page";
        }

        return "UnknownPage";
    }

    private static String capitalize(String s) {
        return s.substring(0, 1).toUpperCase() + s.substring(1);
    }
}
