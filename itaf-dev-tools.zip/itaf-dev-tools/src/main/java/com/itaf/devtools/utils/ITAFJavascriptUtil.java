package com.itaf.devtools.utils;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

/**
 * ITAFJavascriptUtil - JS executor helper
 */
public class ITAFJavascriptUtil {

    protected final JavascriptExecutor js;

    public ITAFJavascriptUtil(WebDriver driver) {
        this.js = (JavascriptExecutor) driver;
    }

    public Object execute(String script, Object... args) {
        return js.executeScript(script, args);
    }
}
