package com.itaf.devtools.lcoatorstudio.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "locator.scoring")
public class LocatorScoringProperties {

    private int dataAttribute;
    private int id;
    private int css;
    private int xpath;

    private int stableBonus;
    private int numericPenalty;

    // getters & setters
    public int getDataAttribute() { return dataAttribute; }
    public void setDataAttribute(int dataAttribute) { this.dataAttribute = dataAttribute; }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getCss() { return css; }
    public void setCss(int css) { this.css = css; }

    public int getXpath() { return xpath; }
    public void setXpath(int xpath) { this.xpath = xpath; }

    public int getStableBonus() { return stableBonus; }
    public void setStableBonus(int stableBonus) { this.stableBonus = stableBonus; }

    public int getNumericPenalty() { return numericPenalty; }
    public void setNumericPenalty(int numericPenalty) { this.numericPenalty = numericPenalty; }
}
