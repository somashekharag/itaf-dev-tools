package com.itaf.devtools.fluent;

import com.itaf.devtools.utils.ITAFElementUtil;
import com.itaf.devtools.utils.ITAFWaitUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

/**
 * Generic FluentCondition returning back to parent chain type T.
 */
public class ITAFFluentCondition<T extends ITAFFluentChain<T>> {

    private final By locator;
    private final WebElement element;
    private final T parent;
    private final ITAFWaitUtil wait;
    private final ITAFElementUtil elementUtil;

    public ITAFFluentCondition(By locator, WebElement element, T parent, ITAFWaitUtil wait) {
        this.locator = locator;
        this.element = element;
        this.parent = parent;
        this.wait = wait;
        this.elementUtil = new ITAFElementUtil(parent.actions().driver());
    }

    private WebElement resolve() {
        if (element != null) return element;
        return wait.visible(locator);
    }

    public T isVisible() {
        resolve();
        return parent;
    }

    public T isNotVisible() {
        try {
            resolve();
            throw new AssertionError("Expected not visible.");
        } catch (Exception ignored) {}
        return parent;
    }

    public T isClickable() {
        if (locator != null) wait.clickable(locator);
        else wait.clickable(resolve());
        return parent;
    }

    public T textContains(String expected) {
        WebElement e = resolve();
        if (!e.getText().contains(expected))
            throw new AssertionError("Expected to contain: " + expected);
        return parent;
    }
}
