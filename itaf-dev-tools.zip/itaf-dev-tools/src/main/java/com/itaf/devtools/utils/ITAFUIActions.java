package com.itaf.devtools.utils;

import com.itaf.devtools.fluent.ITAFFluentChain;
import org.openqa.selenium.WebDriver;

/**
 * UIActions - facade that wires ITAF utilities (pluggable).
 */
public class ITAFUIActions {

    private final WebDriver driver;

    public final ITAFWaitUtil wait;
    public final ITAFElementUtil element;
    public final ITAFClickUtil click;
    public final ITAFTextUtil text;
    public final ITAFBrowserUtil browser;
    public final ITAFAlertUtil alert;
    public final ITAFJavascriptUtil js;
    public final ITAFScreenshotUtil screenshot;

    public ITAFUIActions(WebDriver driver) {
        this(driver, new ITAFDefaultActionsProvider());
    }

    public ITAFUIActions(WebDriver driver, ITAFActionsProvider provider) {
        this.driver = driver;

        this.wait = provider.wait(driver);
        this.element = provider.element(driver);
        this.click = provider.click(driver);
        this.text = provider.text(driver);
        this.browser = provider.browser(driver);
        this.alert = provider.alert(driver);
        this.js = provider.js(driver);
        this.screenshot = provider.screenshot(driver);
    }

    public WebDriver driver() { return driver; }

    public ITAFFluentChain<?> doActions() {
        return new ITAFFluentChain<>(driver, this);
    }
}
