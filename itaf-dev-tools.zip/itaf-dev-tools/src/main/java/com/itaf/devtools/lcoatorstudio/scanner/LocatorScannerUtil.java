
package com.itaf.devtools.lcoatorstudio.scanner;

import com.itaf.devtools.lcoatorstudio.model.LocatorCandidate;
import com.itaf.devtools.lcoatorstudio.model.ScannedElement;
import com.itaf.devtools.lcoatorstudio.utils.CssEscapeUtil;
import com.itaf.devtools.lcoatorstudio.utils.SensitiveAttributeFilter;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LocatorScannerUtil {

    private final WebDriver driver;
    private final LocatorScoringService scoringService;

    public LocatorScannerUtil(WebDriver driver, LocatorScoringService scoringService) {
        this.driver = driver;
        this.scoringService = scoringService;
    }

    public ScannedElement scan(WebElement el, Map<String, String> attrs, String text) {

        List<LocatorCandidate> candidates = new ArrayList<>();


        // SECURITY: filter sensitive attributes at boundary
        Map<String, String> safeAttrs = new HashMap<>();

        attrs.forEach((k, v) -> {
            String safeValue = v;
            if (v != null && v.length() > 100) {
                safeValue = "***REDACTED***";
            }
            safeAttrs.put(k, safeValue);
            if (!SensitiveAttributeFilter.isSensitive(k)) {
                safeAttrs.put(k, v);
            }
        });

        safeAttrs.forEach((k, v) -> {
            if (k.startsWith("data-") || k.equals("aria-label")) {
                String escaped = CssEscapeUtil.escape(v);

                if (v.contains("'") || v.contains("\"")) {
                    System.out.println("Invalid CSS selector found, falling back to xpath");
                    candidates.add(
                            new LocatorCandidate(
                                    "xpath",
                                    "//*[@"+k+"=\"" + v + "\"]"
                            )
                    );
                } else {
                    candidates.add(new LocatorCandidate("css", "[" + k + "='" + escaped + "']"));
                }
            }
        });

        if (safeAttrs.containsKey("id")) {
            candidates.add(new LocatorCandidate("id", safeAttrs.get("id")));
        }

        candidates.add(new LocatorCandidate(
            "xpath",
            "//" + el.getTagName() + "[normalize-space()='" + text + "']"
        ));

        candidates.forEach(c -> {
            c.score = scoringService.score(c);
        });
        candidates.removeIf(c -> !isUnique(c));
        candidates.sort((a, b) -> b.score - a.score);

        ScannedElement result = new ScannedElement();
        result.tag = el.getTagName();
        result.text = text;
        result.attributes = safeAttrs;
        result.bestLocator = candidates.isEmpty() ? null : candidates.get(0);
        result.allLocators = candidates;
        result.capturedAt = LocalDateTime.now();

        return result;

    }

    private boolean isUnique(LocatorCandidate c) {
        By by = c.type.equals("id") ? By.id(c.value)
              : c.type.equals("css") ? By.cssSelector(c.value)
              : By.xpath(c.value);
        return driver.findElements(by).size() == 1;
    }

}
