package com.itaf.devtools.lcoatorstudio.utils;

public class CssEscapeUtil {

    public static String escape(String value) {
        if (value == null) return "";

        return value
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "")
            .replace("\r", "");
    }
}
