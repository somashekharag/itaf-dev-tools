package com.itaf.devtools.fluent;

import com.itaf.devtools.utils.ITAFUIActions;
import org.openqa.selenium.*;

import org.openqa.selenium.support.PageFactory;

/**
 * Generic FluentChain base using self-type generic (F-bounded).
 */
public class ITAFFluentChain<T extends ITAFFluentChain<T>> {

    protected final ITAFUIActions ui;
    protected final int DEFAULT_RETRY = 1;
    protected int retry = DEFAULT_RETRY;

    public ITAFFluentChain(WebDriver driver, ITAFUIActions ui) {
        this.ui = ui;
    }

    protected ITAFUIActions actions() { return ui; }

    @SuppressWarnings("unchecked")
    protected T self() { return (T) this; }

    public <P> P on(Class<P> pageClass) {
        try {
            P page = pageClass.getDeclaredConstructor().newInstance();
            PageFactory.initElements(ui.driver(), page);
            return page;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public T open(String url) {
        ui.browser.open(url);
        return self();
    }

    public T click(By locator) {
        ui.click.click(locator);
        return self();
    }

    public T click(WebElement el) {
        ui.click.click(el);
        return self();
    }

    public T type(By locator, String value) {
        ui.text.type(locator, value);
        return self();
    }

    public T type(WebElement el, String value) {
        ui.text.type(el, value);
        return self();
    }

    public ITAFFluentCondition<T> waitUntil(By locator) {
        return new ITAFFluentCondition<>(locator, null, self(), ui.wait);
    }

    public ITAFFluentCondition<T> waitUntil(WebElement el) {
        return new ITAFFluentCondition<>(null, el, self(), ui.wait);
    }

    public ITAFFluentExpectation expect(By locator) {
        return new ITAFFluentExpectation(locator, null, ui);
    }

    public ITAFFluentExpectation expect(WebElement el) {
        return new ITAFFluentExpectation(null, el, ui);
    }

    public T retry(int attempts) {
        this.retry = Math.max(1, attempts);
        return self();
    }

    public void finish() {
        // hook for reporting
    }
}
