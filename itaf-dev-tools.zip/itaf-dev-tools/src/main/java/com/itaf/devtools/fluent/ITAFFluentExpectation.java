package com.itaf.devtools.fluent;

import com.itaf.devtools.utils.ITAFElementUtil;
import com.itaf.devtools.utils.ITAFUIActions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

/**
 * FluentExpectation - assertions supporting By and WebElement
 */
public class ITAFFluentExpectation {

    private final By locator;
    private final WebElement element;
    private final ITAFUIActions ui;
    private final ITAFElementUtil elementUtil;

    public ITAFFluentExpectation(By locator, WebElement element, ITAFUIActions ui) {
        this.locator = locator;
        this.element = element;
        this.ui = ui;
        this.elementUtil = new ITAFElementUtil(ui.driver());
    }

    private WebElement resolve() {
        if (element != null) return element;
        return elementUtil.get(locator);
    }

    public ITAFFluentExpectation toHaveText(String expected) {
        String actual = resolve().getText();
        if (!actual.equals(expected))
            throw new AssertionError("Expected: " + expected + " but got: " + actual);
        return this;
    }

    public ITAFFluentExpectation toBeVisible() {
        if (!elementUtil.isDisplayed(resolve()))
            throw new AssertionError("Element not visible.");
        return this;
    }
}
