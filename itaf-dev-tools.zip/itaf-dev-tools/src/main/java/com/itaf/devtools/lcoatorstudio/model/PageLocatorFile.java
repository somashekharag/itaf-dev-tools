package com.itaf.devtools.lcoatorstudio.model;

import java.util.ArrayList;
import java.util.List;

public class PageLocatorFile {

    public String pageName;

    public PageLocatorFile() {
    }

    public List<PersistedElement> elements = new ArrayList<>();
}
