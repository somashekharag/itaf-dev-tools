package com.itaf.devtools.utils;

import org.openqa.selenium.WebDriver;

/**
 * ITAFBrowserUtil - browser level helpers
 */
public class ITAFBrowserUtil {

    protected final WebDriver driver;

    public ITAFBrowserUtil(WebDriver driver) {
        this.driver = driver;
    }

    public void open(String url) { driver.get(url); }

    public void refresh() { driver.navigate().refresh(); }

    public void back() { driver.navigate().back(); }

    public void forward() { driver.navigate().forward(); }

    public String getTitle() { return driver.getTitle(); }
}
