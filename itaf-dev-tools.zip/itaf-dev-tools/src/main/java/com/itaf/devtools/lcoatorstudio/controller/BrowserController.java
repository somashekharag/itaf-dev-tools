
package com.itaf.devtools.lcoatorstudio.controller;

import com.itaf.devtools.lcoatorstudio.selenium.DriverStore;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/browser")
public class BrowserController {

    @PostMapping("/start")
    public void start(@RequestParam String url) {
        WebDriver driver = new ChromeDriver();
        DriverStore.set(driver);
        driver.get(url);
    }
}
