package com.itaf.devtools.utils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 * ITAFElementUtil - atomic element helpers
 */
public class ITAFElementUtil {

    protected final WebDriver driver;
    protected final ITAFWaitUtil wait;

    public ITAFElementUtil(WebDriver driver) {
        this.driver = driver;
        this.wait = new ITAFWaitUtil(driver);
    }

    public WebElement get(By locator) {
        return wait.visible(locator);
    }

    public WebElement get(WebElement element) {
        return wait.visible(element);
    }

    public String getText(By locator) {
        return get(locator).getText();
    }

    public boolean isDisplayed(By locator) {
        try { return get(locator).isDisplayed(); } catch (Exception e) { return false; }
    }

    public boolean isDisplayed(WebElement element) {
        try { return get(element).isDisplayed(); } catch (Exception e) { return false; }
    }
}
