package com.itaf.devtools.lcoatorstudio.scanner;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.itaf.devtools.lcoatorstudio.model.PageLocatorFile;
import com.itaf.devtools.lcoatorstudio.model.PersistedElement;
import org.springframework.stereotype.Service;

import java.nio.file.Files;
import java.nio.file.Path;

@Service
public class LocatorPersistenceService {

    private final ObjectMapper mapper;

    public LocatorPersistenceService(ObjectMapper mapper) {
        this.mapper = mapper;
    }

    public void persist(
            String pageName,
            PersistedElement newElement) {

        try {
            Path pageDir = Path.of("locator-output", pageName);
            Files.createDirectories(pageDir);

            Path jsonFile = pageDir.resolve("locators.json");

            PageLocatorFile pageData;

            if (Files.exists(jsonFile)) {
                pageData = mapper.readValue(
                        jsonFile.toFile(),
                        PageLocatorFile.class);
            } else {
                pageData = new PageLocatorFile();
                pageData.pageName = pageName;
            }

            pageData.elements.add(newElement);

            mapper.writerWithDefaultPrettyPrinter()
                  .writeValue(jsonFile.toFile(), pageData);

        } catch (Exception e) {
            throw new RuntimeException("Failed to persist locator JSON", e);
        }
    }
}
