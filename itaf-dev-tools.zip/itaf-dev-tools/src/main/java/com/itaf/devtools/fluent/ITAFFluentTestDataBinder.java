package com.itaf.devtools.fluent;

import com.itaf.devtools.utils.ITAFTextUtil;
import org.openqa.selenium.By;

import java.lang.reflect.Field;
import java.util.Map;

/**
 * FluentTestDataBinder - simple name-based binder
 */
public class ITAFFluentTestDataBinder {

    private final ITAFTextUtil textUtil;

    public ITAFFluentTestDataBinder(ITAFTextUtil textUtil) {
        this.textUtil = textUtil;
    }

    public void fill(Map<String, String> data) {
        data.forEach((k,v) -> textUtil.type(By.name(k), v));
    }

    public void fill(Object pojo) {
        try {
            for (Field f : pojo.getClass().getDeclaredFields()) {
                f.setAccessible(true);
                Object v = f.get(pojo);
                if (v != null) textUtil.type(By.name(f.getName()), v.toString());
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
