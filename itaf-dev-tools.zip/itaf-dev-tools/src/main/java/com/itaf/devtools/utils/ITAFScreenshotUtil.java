package com.itaf.devtools.utils;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

/**
 * ITAFScreenshotUtil - screenshot helper
 */
public class ITAFScreenshotUtil {

    protected final WebDriver driver;

    public ITAFScreenshotUtil(WebDriver driver) {
        this.driver = driver;
    }

    public byte[] fullPage() {
        return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
    }
}
