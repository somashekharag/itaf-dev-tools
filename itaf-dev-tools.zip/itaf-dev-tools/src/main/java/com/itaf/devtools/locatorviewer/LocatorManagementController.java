package com.itaf.devtools.locatorviewer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.itaf.devtools.lcoatorstudio.model.PageLocatorFile;
import org.springframework.web.bind.annotation.*;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@RestController
@RequestMapping("/api/locators")
public class LocatorManagementController {
    private final ObjectMapper mapper;

    private static final Path ROOT =
            Path.of("locator-output");

    public LocatorManagementController(ObjectMapper mapper) {
        this.mapper = mapper;
    }

    @GetMapping("/pages")
    public List<String> listPages() throws Exception {
        if (!Files.exists(ROOT)) return List.of();

        try (Stream<Path> stream = Files.list(ROOT)) {
            return stream
                    .filter(Files::isDirectory)
                    .map(p -> p.getFileName().toString())
                    .collect(Collectors.toList());
        }
    }

    @GetMapping("/{pageName}")
    public PageLocatorFile getPage(@PathVariable String pageName)
            throws Exception {

        Path file = ROOT.resolve(pageName).resolve("locators.json");
        if (!Files.exists(file)) {
            throw new RuntimeException("Page not found");
        }

        return mapper.readValue(file.toFile(), PageLocatorFile.class);
    }

    @PutMapping("/element")
    public void updateElementName(
            @RequestParam String pageName,
            @RequestParam String oldElementName,
            @RequestParam String newElementName) throws Exception {

        Path jsonFile =
                ROOT.resolve(pageName).resolve("locators.json");

        PageLocatorFile file =
                mapper.readValue(jsonFile.toFile(), PageLocatorFile.class);

        file.elements.stream()
                .filter(e -> e.elementName.equals(oldElementName))
                .findFirst()
                .ifPresent(e -> e.elementName = newElementName);

        mapper.writerWithDefaultPrettyPrinter()
                .writeValue(jsonFile.toFile(), file);
    }
}
