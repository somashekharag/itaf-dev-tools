package com.itaf.devtools.lcoatorstudio.selenium;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ElementScreenshotUtil {

    private static final DateTimeFormatter TS =
            DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss_SSS");

    public static String capture(
            WebElement element,
            String pageName,
            String elementName) {

        try {
            File src = element.getScreenshotAs(OutputType.FILE);

            Path dir = Path.of(
                    "locator-output", pageName, "screenshots");

            Files.createDirectories(dir);

            String filename =
                    elementName + "__" +
                            LocalDateTime.now().format(TS) + ".png";

            Path target = dir.resolve(filename);

            Files.copy(
                    src.toPath(),
                    target,
                    StandardCopyOption.REPLACE_EXISTING);

            return target.toString();

        } catch (Exception e) {
            throw new RuntimeException(
                    "Failed to capture element screenshot", e);
        }
    }
}
